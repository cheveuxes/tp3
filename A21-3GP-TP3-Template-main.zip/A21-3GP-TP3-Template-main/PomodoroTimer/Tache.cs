﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;


[assembly:InternalsVisibleTo("TestTache")]

//SETTER & GETTER DE LA CLASSE 

namespace PomodoroTimer
{
    public class Tache
    {
        public string Description
        {
            set; get;
        }
        public int NB_Pomodoros_Prevus
        {
            set; get;
        }
        public int NB_Pomodoros_Terminés
        {
            set; get;
        }
        public TacheStatu Statu
        {
            set; get;
        }
     

        //constructeur par défaut
        public Tache() { }

        //constructeur d'initialisation
        public Tache(String description, int nb_Pomodoros_Prevus,int  nb_Pomodoros_Terminés)
        {
            this.Description = description;
            this.NB_Pomodoros_Prevus = nb_Pomodoros_Prevus;
            this.NB_Pomodoros_Terminés = nb_Pomodoros_Terminés;
            this.Statu = TacheStatu.PLANIFIEE;
        }
    }
}

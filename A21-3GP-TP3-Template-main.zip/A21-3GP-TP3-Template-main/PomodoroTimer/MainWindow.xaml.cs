﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Xml;

namespace PomodoroTimer
{
    public partial class MainWindow : Window
    {
        //code du prof
        public static RoutedCommand cmdDemarrerPomodoro = new RoutedCommand();
        public static RoutedCommand cmdInterromprePomodoro = new RoutedCommand();

        private const int NOMBRE_SECONDES = 60;
        private BackgroundWorker _tempsPomodoro;
        public static List<Tache> ListeDesTache = new List<Tache>();
        string _path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\taches.xml";
        XmlDocument MyXmlFile = new XmlDocument();

        public MainWindow()
        {
            InitializeComponent();
            GetTasks();
        }

        // Commentaires du professeur -> Eric Wenass
        // ok donc, code de Eric-> Début du code pour la minuterie, documents que vous nous aviez déjà donné sur git
		// Commentaire du prof ->Il devra être adapté aux spécifications du travail
        private void DemarrerPomodoro()
        {
            if (_tempsPomodoro != null && _tempsPomodoro.IsBusy)
            {
                _tempsPomodoro.RunWorkerCompleted -= TerminerPomodoro;
                _tempsPomodoro.ProgressChanged -= AfficherTemps;
                _tempsPomodoro.CancelAsync();
            }

            AfficherTemps(NOMBRE_SECONDES);

            _tempsPomodoro = new BackgroundWorker();
            _tempsPomodoro.WorkerSupportsCancellation = true;
            _tempsPomodoro.WorkerReportsProgress = true;
            _tempsPomodoro.DoWork += DeduireTemps;
            _tempsPomodoro.ProgressChanged += AfficherTemps;
            _tempsPomodoro.RunWorkerCompleted += TerminerPomodoro;
            _tempsPomodoro.RunWorkerAsync();
        }

        private void DeduireTemps(object sender, DoWorkEventArgs e)
        {
            int progress = 0;
            int secondes = NOMBRE_SECONDES;

            BackgroundWorker worker = sender as BackgroundWorker;

            while (secondes > 0 && ! worker.CancellationPending)
            {
                Thread.Sleep(1000);
                secondes--;
                progress++;
                worker.ReportProgress(progress * 100 / NOMBRE_SECONDES, secondes);
            }
        }

        private void AfficherTemps(object sender, ProgressChangedEventArgs e)
        {
            AfficherTemps((int)e.UserState);
        }

        private void AfficherTemps(int secondesRestantes)
        {
            TimeSpan ts = TimeSpan.FromSeconds(secondesRestantes);
            TextTemps.Text = ts.ToString(@"mm\:ss");
        }
        
        private void TerminerPomodoro(object sender, RunWorkerCompletedEventArgs e)
        {
            // Pomodoro terminé yes => code pour modifier  le nombre pomodoros terminés et le statut de la tâche selectionnée 
            MessageBoxResult result_1 =     MessageBox.Show("Est-ce que le pomodoro a été complété ?", "Temps expiré", MessageBoxButton.YesNo);
            if (result_1 == MessageBoxResult.Yes)
            {
                ListeDesTache[Trouver_Tache_Index_Par_DESC(Taches_Listbox.SelectedItem.ToString())].NB_Pomodoros_Terminés =
                    ListeDesTache[Trouver_Tache_Index_Par_DESC(Taches_Listbox.SelectedItem.ToString())].NB_Pomodoros_Terminés + 1;

                //Modification du statut d'une tâche et la mettre en_cours
                if(ListeDesTache[Trouver_Tache_Index_Par_DESC(Taches_Listbox.SelectedItem.ToString())].NB_Pomodoros_Terminés==1 && ListeDesTache[Trouver_Tache_Index_Par_DESC(Taches_Listbox.SelectedItem.ToString())].NB_Pomodoros_Prevus > 1)
                {
                    ListeDesTache[Trouver_Tache_Index_Par_DESC(Taches_Listbox.SelectedItem.ToString())].Statu = TacheStatu.EN_COURS;
                }

                //Méthode pour mettre à jour le fichier XML après les modifications
                RedefinirXmlFile();
                

            }
            //Else pour terminer le if, pour ne pas me mélanger. Elle ne fera rien dans le code. 
            else
            { 
            }
            //Message
            MessageBoxResult result_2 = MessageBox.Show("Est-ce que la tâche est complétée ?", Taches_Listbox.SelectedItem.ToString(), MessageBoxButton.YesNo);
            if (result_2 == MessageBoxResult.Yes)
            {
                ListeDesTache[Trouver_Tache_Index_Par_DESC(Taches_Listbox.SelectedItem.ToString())].Statu =
                    TacheStatu.COMPLETEE;
                RedefinirXmlFile();
                
            }
            else
            {
            }

        }

        private void InterromprePomodoro()
        {
            if (_tempsPomodoro != null && _tempsPomodoro.IsBusy)
            {
                _tempsPomodoro.RunWorkerCompleted -= TerminerPomodoro;
                _tempsPomodoro.ProgressChanged -= AfficherTemps;
                _tempsPomodoro.CancelAsync();
            }
            AfficherTemps(0);
            
            // Pomodoro interrompu => code pour modifier  le Nombre Pomodoros Terminés et le statu de la tache selectionneé
            MessageBoxResult result_2 = MessageBox.Show("Est-ce que la tache est  compléteé ?", Taches_Listbox.SelectedItem.ToString(), MessageBoxButton.YesNo);
            if (result_2 == MessageBoxResult.Yes)
            {
                ListeDesTache[Trouver_Tache_Index_Par_DESC(Taches_Listbox.SelectedItem.ToString())].NB_Pomodoros_Terminés =
                    ListeDesTache[Trouver_Tache_Index_Par_DESC(Taches_Listbox.SelectedItem.ToString())].NB_Pomodoros_Terminés + 1;

                ListeDesTache[Trouver_Tache_Index_Par_DESC(Taches_Listbox.SelectedItem.ToString())].Statu =
                    TacheStatu.COMPLETEE;
               
                RedefinirXmlFile(); // modifier fichier tache.Xml
                
            }
            else
            {

            }
        }
        //Commande de pomodoros, fait par l'enseignant
        private void CommandedDemarrerPomodoro_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void CommandedDemarrerPomodoro_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            DemarrerPomodoro();
        }

        private void CommandeInterromprePomodoro_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = _tempsPomodoro != null && _tempsPomodoro.IsBusy;
        }

        private void CommandeInterromprePomodoro_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            InterromprePomodoro();
        }
        //pour ajouter le nombre des pomodoros prévus d'une nouvelle tâche
        private void plus_Click(object sender, RoutedEventArgs e)
        {
            Previsions_pomodoro_label.Content = int.Parse(Previsions_pomodoro_label.Content.ToString()) + 1;
        }
        //pour diminuer le nombre des pomodoros prévus d'une nouvelle tâche
        private void moins_Click(object sender, RoutedEventArgs e)
        {
            //code pour ajouter et diminuer le nombre des pomodoro prévus
            int value = int.Parse(Previsions_pomodoro_label.Content.ToString()) - 1;
            if (value <= 0)
                Previsions_pomodoro_label.Content = 0;
            else
            {
                //affichage dans label
                Previsions_pomodoro_label.Content = int.Parse(Previsions_pomodoro_label.Content.ToString()) - 1;
            }
        }
        
        private void Ajouter_tache_btn_Click(object sender, RoutedEventArgs e)
        {
            //code pour ajouter une tâche dans le fichier Xml
            if (! string.IsNullOrEmpty(Description.Text))
            {
                
                if (int.Parse(Previsions_pomodoro_label.Content.ToString()) > 0)
                {
                    MyXmlFile.Load(_path);
                    Tache T = new Tache();
                    T.Description = Description.Text;
                    T.NB_Pomodoros_Prevus = int.Parse(Previsions_pomodoro_label.Content.ToString());
                    T.NB_Pomodoros_Terminés = 0;
                    T.Statu = TacheStatu.PLANIFIEE;

                    XmlNode Tachenode = MyXmlFile.CreateNode(XmlNodeType.Element, "Tache", "");
                    XmlAttribute TacheNode_completeattr = MyXmlFile.CreateAttribute("PomodorosCompletes");
                    XmlAttribute TacheNode_prevusattr = MyXmlFile.CreateAttribute("PomodorosPrevus");
                    XmlAttribute TacheNode_statuattr = MyXmlFile.CreateAttribute("Statut");
                    TacheNode_completeattr.InnerText = T.NB_Pomodoros_Terminés.ToString();
                    TacheNode_prevusattr.InnerText = T.NB_Pomodoros_Prevus.ToString();
                    TacheNode_statuattr.InnerText = T.Statu.ToString();
                    Tachenode.Attributes.Append(TacheNode_completeattr);
                    Tachenode.Attributes.Append(TacheNode_prevusattr);
                    Tachenode.Attributes.Append(TacheNode_statuattr);
                    MyXmlFile.Save(_path);
                    XmlNode Descriptionnode = MyXmlFile.CreateNode(XmlNodeType.Element, "Description", "");
                    Descriptionnode.InnerText = T.Description;

                    Tachenode.AppendChild(Descriptionnode);
                    MyXmlFile.SelectSingleNode("//Taches").AppendChild(Tachenode);
                    MyXmlFile.Save(_path);
                    MessageBox.Show("la tâche est bien ajoutée!");
                    ListeDesTache.Add(T);
                    Taches_Listbox.Items.Add(T.Description);

                }
                else
                    MessageBox.Show("le nombre de pomodoros <1");
            }
            else MessageBox.Show("la description de la tâche est vide");
         }

        public void GetTasks()
        {
            //Code pour récupérer la liste des tâches dans notre objet <list> (List<Tache> ListeDesTache)
            ListeDesTache.Clear();
            MyXmlFile.Load(_path);
            Tache T = new Tache();

           
            foreach (XmlElement xn in MyXmlFile.SelectNodes("//Taches/Tache"))
            {
                T = new Tache();
               
                T.Description = xn["Description"].InnerText;
                T.NB_Pomodoros_Prevus = int.Parse(xn.GetAttribute("PomodorosPrevus").ToString());
                T.NB_Pomodoros_Terminés = int.Parse(xn.GetAttribute("PomodorosCompletes").ToString());
                if (xn.GetAttribute("Statut").ToString().Equals("PLANIFIEE"))
                    T.Statu = TacheStatu.PLANIFIEE;
                else if (xn.GetAttribute("Statut").ToString().Equals("EN_COURS"))
                    T.Statu = TacheStatu.EN_COURS;
                else
                    T.Statu = TacheStatu.COMPLETEE;
                
                if (T.Statu == TacheStatu.EN_COURS || T.Statu == TacheStatu.PLANIFIEE)
                    Taches_Listbox.Items.Add(T.Description);
                ListeDesTache.Add(T);



            }

        }

        private void Supprimer_Tache_Click(object sender, RoutedEventArgs e)
        {
            //code pour supprimer une tâche selectionnée
            string tache = Taches_Listbox.SelectedItem.ToString();

          
            foreach (Tache T in ListeDesTache) //Supprimer la tâche de listbox des tâches 
            {
               

                if (T.Description.Equals(tache))
                {
                    ListeDesTache.Remove(T);
                    Taches_Listbox.Items.Remove(tache);
                    break;

                }

            }
            MyXmlFile.Load(_path);
            MyXmlFile.SelectSingleNode("//Taches").RemoveAll(); //Vider fichier xml pour réécrire le ficher avec les modifications
            MyXmlFile.Save(_path);
            //Écrire dans le fichier xml toutes les tâches après les modifications (objet :  (List<Tache> ListeDesTache)
            foreach (Tache x in ListeDesTache) 
            {
                XmlNode Tachenode = MyXmlFile.CreateNode(XmlNodeType.Element, "Tache", "");
                XmlAttribute TacheNode_completeattr = MyXmlFile.CreateAttribute("PomodorosCompletes");
                XmlAttribute TacheNode_prevusattr = MyXmlFile.CreateAttribute("PomodorosPrevus");
                XmlAttribute TacheNode_statuattr = MyXmlFile.CreateAttribute("Statut");
                TacheNode_completeattr.InnerText = x.NB_Pomodoros_Terminés.ToString();
                TacheNode_prevusattr.InnerText = x.NB_Pomodoros_Prevus.ToString();
                TacheNode_statuattr.InnerText = x.Statu.ToString();
                Tachenode.Attributes.Append(TacheNode_completeattr);
                Tachenode.Attributes.Append(TacheNode_prevusattr);
                Tachenode.Attributes.Append(TacheNode_statuattr);
                MyXmlFile.Save(_path);
                XmlNode Descriptionnode = MyXmlFile.CreateNode(XmlNodeType.Element, "Description", "");
                Descriptionnode.InnerText = x.Description;

                Tachenode.AppendChild(Descriptionnode);
                MyXmlFile.SelectSingleNode("//Taches").AppendChild(Tachenode);
                MyXmlFile.Save(_path);
               
            }




        }

        private void Taches_Listbox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //sélection d'une tâche
            Tache instance = new Tache();
            if(Taches_Listbox.SelectedIndex!=-1 && Taches_Listbox.SelectedItem != null) { 
                foreach (Tache T in ListeDesTache)
                {

                    if (T.Description.Equals(Taches_Listbox.SelectedItem.ToString()))
                    {
                        PomodorosCompletesinfo.Content = T.NB_Pomodoros_Terminés.ToString();
                        PomodorosPrevusinfo.Content = T.NB_Pomodoros_Prevus.ToString();
                        Statutachelabel.Content = T.Statu;

                        instance = T;

                      
                    }

                }
            }
            //modification des buttons du timer par rapport au statut et nb pomodoro prévus de la tâche
            if (instance.NB_Pomodoros_Prevus > 0 && !instance.Statu.ToString().Equals("COMPLETEE"))
                Démarrer_pomodoro_btn.IsEnabled = true;
            else
                Démarrer_pomodoro_btn.IsEnabled = false;







        }

        private void T_encours_Checked(object sender, RoutedEventArgs e)
        {
            //afficher les taches en cours
            Aciver_Taches_Par_Statu("EN_COURS");

        }

        private void T_encours_Unchecked(object sender, RoutedEventArgs e)
        {
            //cacher les tâches en cours
            Desaciver_Taches_Par_Statu("EN_COURS");
        }
       
        
        public void Aciver_Taches_Par_Statu( String valeur)//méthode pour afficher une tâche par rapport au statut en paramètre
        {
            String Tache_statu = "";
                foreach (Tache T in ListeDesTache)
                {
                Tache_statu = T.Statu.ToString();

                    if (Tache_statu.Equals(valeur))
                        Taches_Listbox.Items.Add(T.Description);
                 }
        }
        public void Desaciver_Taches_Par_Statu(String valeur)//méthode pour cacher une tâche par rapport au statut en paramètre
        {
            String Tache_st;
            foreach (Tache T in ListeDesTache)
            {
                Tache_st = T.Statu.ToString();

                if (Tache_st.Equals(valeur))

                    Taches_Listbox.Items.Remove(T.Description);

            }
        }

        private void T_Plannifiies_Checked(object sender, RoutedEventArgs e)
        {
            //afficher les tâches PLANIFIEE
            Aciver_Taches_Par_Statu("PLANIFIEE");
        }

        private void T_Plannifiies_Unloaded(object sender, RoutedEventArgs e)
        {

        }

        private void T_Plannifiies_Unchecked(object sender, RoutedEventArgs e)
        {
            //cacher les tâches PLANIFIEE
            Desaciver_Taches_Par_Statu("PLANIFIEE");
        }

        private void T_Completees_Checked(object sender, RoutedEventArgs e)
        {
            //afficher les tâches COMPLETEE
            Aciver_Taches_Par_Statu("COMPLETEE");
        }

        private void T_Completees_Unchecked(object sender, RoutedEventArgs e)
        {
            //cacher les taches COMPLETEE
            Desaciver_Taches_Par_Statu("COMPLETEE");
        }
        
        

        public Tache Trouver_Tache_Par_DESC(string Description) //chercher une tâche par sa description
        {
            Tache T = new Tache(); ;
            T= ListeDesTache.Find(T => T.Description.Contains(Description));
            return T;

        }
        public int Trouver_Tache_Index_Par_DESC(string Description) //chercher l'index d'une tâche par sa description
        {
            int INDEX = -9999;
            INDEX= ListeDesTache.FindIndex(T => T.Description.Contains(Description));
            return INDEX;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
          
            MessageBox.Show(Trouver_Tache_Index_Par_DESC(Taches_Listbox.SelectedItem.ToString()).
                ToString());
        }

        public void RedefinirXmlFile()//Mettre à jour le fichier tache.xml à chaque changement 
        {

            MyXmlFile.Load(_path);
            MyXmlFile.SelectSingleNode("//Taches").RemoveAll();
            MyXmlFile.Save(_path);

            foreach (Tache x in ListeDesTache)
            {
                XmlNode Tachenode = MyXmlFile.CreateNode(XmlNodeType.Element, "Tache", "");
                XmlAttribute TacheNode_completeattr = MyXmlFile.CreateAttribute("PomodorosCompletes");
                XmlAttribute TacheNode_prevusattr = MyXmlFile.CreateAttribute("PomodorosPrevus");
                XmlAttribute TacheNode_statuattr = MyXmlFile.CreateAttribute("Statut");
                TacheNode_completeattr.InnerText = x.NB_Pomodoros_Terminés.ToString();
                TacheNode_prevusattr.InnerText = x.NB_Pomodoros_Prevus.ToString();
                TacheNode_statuattr.InnerText = x.Statu.ToString();
                Tachenode.Attributes.Append(TacheNode_completeattr);
                Tachenode.Attributes.Append(TacheNode_prevusattr);
                Tachenode.Attributes.Append(TacheNode_statuattr);
                MyXmlFile.Save(_path);
                XmlNode Descriptionnode = MyXmlFile.CreateNode(XmlNodeType.Element, "Description", "");
                Descriptionnode.InnerText = x.Description;

                Tachenode.AppendChild(Descriptionnode);
                MyXmlFile.SelectSingleNode("//Taches").AppendChild(Tachenode);
                MyXmlFile.Save(_path);

            }

        }

     
    }
}
